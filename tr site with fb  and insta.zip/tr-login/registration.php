<<?php 


	session_start();

	$con = mysqli_connect('localhost','root');
	if($con)
	{
		echo"connection sucessful";
	}
	else
	{
		echo "connection unsucessful";
	}


mysqli_select_db($con, 'session');



$email = $_POST['email'];
$password = $_POST['password'];


$q = "select * from sigin where email = '$email' && password1 = '$password' ";

$result = mysqli_query($con, $q);



$num = mysqli_num_rows($result);

if ($num == 1) {
	echo "sorry the same id is already made plz use login and login with you id";
}
else{
	$qy = "insert into signin(email , password1) values ('$email' , $password)";
	mysqli_query($con, $qy);
}

 ?>