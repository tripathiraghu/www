-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2018 at 07:02 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `table`
--

-- --------------------------------------------------------

--
-- Table structure for table `rtable`
--

CREATE TABLE `rtable` (
  `ID` int(11) NOT NULL,
  `Firstname` varchar(255) NOT NULL,
  `Lastname` varchar(255) NOT NULL,
  `Displayname` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rtable`
--

INSERT INTO `rtable` (`ID`, `Firstname`, `Lastname`, `Displayname`, `Email`, `Password`) VALUES
(1, 'Firstname', 'Lastname', 'Displayname', 'Email', 'Password'),
(2, 'Firstname', 'Lastname', 'Displayname', 'Email', 'Password'),
(3, 'Firstname', 'Lastname', 'Displayname', 'Email', 'Password'),
(4, 'Firstname', 'Lastname', 'Displayname', 'Email', 'Password'),
(5, 'first_name', 'Lastname', 'Displayname', 'Email', 'Password'),
(6, 'raghav', 'tripathi', 'TripathiRaghu', 'tripathiraghu1@gmail.com', 'e807f1fcf82d132f9bb018ca6738a19f'),
(7, 'raghav', 'tripathi', 'w``', 'tripathiraghu1@gmail.com', '8098ab4af3b1af7d11da03db2a3efe82'),
(8, 'tr', 'tr', 'tr', 'tr@tr.com', 'e7d707a26e7f7b6ff52c489c60e429b1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `rtable`
--
ALTER TABLE `rtable`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rtable`
--
ALTER TABLE `rtable`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
