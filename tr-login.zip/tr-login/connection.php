<?php
//here is the code for the connection
$conn = mysqli_connect("localhost","root","","table");

if(!$conn)
{
	echo "Database connection Failed... :((";
}

?>