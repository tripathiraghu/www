<?php
$server="localhost";
$user="id6374141_chitchat";
$password="bjnr@DEC12";
$db="id6374141_root";
$con= mysqli_connect("$server","$user","$password","$db");
?>