<?php
$server="localhost";
$user="root";
$password="";
$db="parth";
$con= mysqli_connect("$server","$user","$password","$db");
?>