<?php
//here is the code for registration..

require_once('connection.php');
$fname = $lname = $dname = $email = $password = $pwd = '';

$fname = $_POST['first_name'];
$lname = $_POST['last_name'];
$dname = $_POST['display_name'];
$email = $_POST['email'];
$pwd = $_POST['password'];
$password = MD5($pwd);


$sql = "INSERT INTO rtable(Firstname,Lastname,Displayname,Email,Password) VALUES (
'$fname','$lname','$dname','$email','$password')";
$result = mysqli_query($conn, $sql);
if($result)
{
	header ("location: join.php");

}
else
{
	echo "Error: ".$sql;
}
?>