<!DOCTYPE html>
<html style="height: 100%">

<head>
    <meta charset="utf-8">
    <meta name="description" content="Tripathi Raghu ">
  <meta name="keywords" content="Tripathi raghu,Tripathi Raghu,Tripathiraghu,TripathiRaghu,tripathiraghu,raghutripathi,raghavtripathi,RaghavTripathi,Raghav Tripathi,contact,mobile_number,Email">
  <meta name="author" content="Tripathi Raghu">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/jpg" href="assets/img/logo_2.png" >
    <title>Register | Tripathi Raghu</title>
    <link rel="stylesheet" type="text/css" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/sticky-footer.css">
</head>

<body onload="myFunction()" style="background-color: #fff; margin:0;height: 100%;">
    
<div class="preload" id="loader">
    <div class="icon">
        <img src="assets/img/logo.png"></div>
            
    <div class="loader-frame">
        <div class="loader1" id="loader1"></div>
        <div class="loader2" id="loader2"></div>
        
    </div>
</div>
</div>

<!--NAV BAR code-->
    <nav class="navbar navbar-default">
        <div class="container-fluid" style="background-color: #1d0d0d !important">
            <div class="navbar-header">
                <a class="navbar-brand navbar-link" href="tripathiraghu.tk"> <img src="assets/img/logo12.png" class="imgnav"></a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav">
                    <li role="presentation"><a href="index.html">Home </a></li>
                    <li role="presentation"><a href="about.html">About </a></li>
                    <li role="presentation"><a href="contact.html">Contact Me</a></li>
                    <li role="presentation"><a href="join.php">Join Gang</a></li>
                </ul>
            </div>
        </div>
    </nav>
<!--Registration form-->

        <section id="content">
            <div class="container">

                <div class="row">
                    <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
                        <form role="form" class="register-form" action="regitration_code.php" method="post">
                            <h2>Please Sign Up <small>It's free and always will be.</small></h2>
                            <hr class="colorgraph">
                            <div class="row">
                                <div class="col-xs-12 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="first_name" id="first_name" class="form-control input-lg" placeholder="First Name" tabindex="1">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="text" name="last_name" id="last_name" class="form-control input-lg" placeholder="Last Name" tabindex="2">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" name="display_name" id="display_name" class="form-control input-lg" placeholder="Display Name" tabindex="3">
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" id="email" class="form-control input-lg" placeholder="Email Address" tabindex="4">
                            </div>
                            <div class="row">
                                <div class="col-xs-12 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="password" name="password" id="password" class="form-control input-lg" placeholder="Password" tabindex="5">
                                    </div>
                                </div>
                                <div class="col-xs-12 col-sm-6 col-md-6">
                                    <div class="form-group">
                                        <input type="password" name="password_confirmation" id="password_confirmation" class="form-control input-lg" placeholder="Confirm Password" tabindex="6">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-xs-4 col-sm-3 col-md-3">
                                    <span class="button-checkbox">
                        <!--<button type="button" class="btn" data-color="info" tabindex="7">I Agree</button>
                        <input type="checkbox" name="t_and_c" id="t_and_c" class="hidden" value="1">-->
                        <input type="checkbox" name="vehicle" value="Bike">I Agree<br>
                    </span>
                                </div>
                                <div class="col-xs-8 col-sm-9 col-md-9">
                                    By clicking <strong class="label " style="background-color: #1d0d0d;">Register</strong>, you agree to the <a href="#" data-toggle="modal" data-target="#t_and_c_m">Terms and Conditions</a> set out by this site, including our Cookie Use.
                                </div>
                            </div>

                            <hr class="colorgraph">
                            <div class="row">
                                <div class="col-xs-12 col-md-6" style="    margin-bottom: 27px;"><input type="submit" value="Register" class="btn btn-theme btn-block btn-lg" tabindex="7"></div>
                                <div class="col-xs-12 col-md-6">Already have an account? <a href="join.php">Sign In</a></div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Modal -->
                <div class="modal fade" id="t_and_c_m" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                <h4 class="modal-title" id="myModalLabel">Terms & Conditions</h4>
                            </div>
                            <div class="modal-body">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Similique, itaque, modi, aliquam nostrum at sapiente consequuntur natus odio reiciendis perferendis rem nisi tempore possimus ipsa porro delectus quidem dolorem ad.</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Similique, itaque, modi, aliquam nostrum at sapiente consequuntur natus odio reiciendis perferendis rem nisi tempore possimus ipsa porro delectus quidem dolorem ad.</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">I Agree</button>
                            </div>
                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                <!-- /.modal -->
            </div>
        </section>
<!--registration form end--->


<footer class="footer" >
      <div class="container">
        <a href="http://tripathiraghu.tk"><span class="text-muted" align="center">Designed by Tripathi raghu</span></a>
      </div>
</footer>
        <!-- footer end-->





<script type="text/javascript" src="assets/js/loader.js"></script>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>