<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="description" content="Tripathi Raghu ">
  <meta name="keywords" content="Tripathi raghu,Tripathi Raghu,Tripathiraghu,TripathiRaghu,tripathiraghu,raghutripathi,raghavtripathi,RaghavTripathi,Raghav Tripathi,contact,mobile_number,Email">
  <meta name="author" content="Tripathi Raghu">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/jpg" href="assets/img/logo_2.png" >
    <title>Join | Tripathi Raghu</title>
    <link rel="stylesheet" type="text/css" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/sticky-footer.css">
</head>
<body onload="myFunction()" style="background-color: #fff; margin:0;">
    
<div class="preload" id="loader">
    <div class="icon">
        <img src="assets/img/logo.png"></div>
            
    <div class="loader-frame">
        <div class="loader1" id="loader1"></div>
        <div class="loader2" id="loader2"></div>
        
    </div>
</div>
</div>

<!--NAV BAR code-->
    <nav class="navbar navbar-default">
        <div class="container-fluid" style="background-color: #1d0d0d !important">
            <div class="navbar-header">
                <a class="navbar-brand navbar-link" href="tripathiraghu.tk"> <img src="assets/img/logo12.png" class="imgnav"></a>
                <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            </div>
            <div class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav">
                    <li  role="presentation"><a href="index.html">Home </a></li>
                    <li role="presentation"><a href="about.html">About </a></li>
                    <li role="presentation"><a href="contact.html">Contact Me</a></li>
                    <li class="active" role="presentation"><a href="join.php">Join Gang</a></li>
                </ul>
            </div>
        </div>
    </nav>



<section id="content">
    <div class="container" >

      <div class="row">
           <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
             <form role="form" class="register-form" action="login_code.php" method="post">
                            <h2>Sign in <small>manage your account</small></h2>
                            <hr class="colorgraph">

                            <div class="form-group">
                                <input type="text" name="email" id="email" class="form-control input-lg" placeholder="Email Address" tabindex="4">
                            </div>
                            <div class="form-group">
                                <input type="password" name="password"  class="form-control input-lg" id="Password" placeholder="Password">
                            </div>

                            <div class="row">
                                <div class="col-xs-4 col-sm-3 col-md-3">
                            
                                </div>
                            </div>

                            <hr class="colorgraph">
                            <div class="row">
                                <div class="col-xs-12 col-md-6 submitbtn"><input type="submit" value="Sign in" class="btn  btn-block btn-lg" tabindex="7" class=""></div>
                                <div class="col-xs-12 col-md-6">Don't have an account? <a href="register.php">Register</a></div>
                            </div>
                        </form>
                    </div>
                </div>

            </div>
        </section>






<footer class="footer" >
      <div class="container">
        <a href="http://tripathiraghu.tk"><span class="text-muted" align="center">Designed by Tripathi raghu</span></a>
      </div>
</footer>
        <!-- footer end-->









<script type="text/javascript" src="assets/js/loader.js"></script>

    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>