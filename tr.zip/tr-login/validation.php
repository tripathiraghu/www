<<?php 


	session_start();

	$con = mysqli_connect('localhost','root');
	if($con)
	{
		echo"connection sucessful";
	}
	else
	{
		echo "connection unsucessful";
	}


mysqli_select_db($con, 'session');



$email = $_POST['name'];
$password = $_POST['password'];


$q = "select * from sigin where email = '$email' && password1 = '$password' ";

$result = mysqli_query($con, $q);



$num = mysqli_num_rows($result);

if ($num == 1) {
	$_SESSION['username']  = $email;
	header('loaction:index.html');
}
else{
	$qy = "insert into signin(email , password1) values ('$email' , $password)";
	mysqli_query($con, $qy);
}

 ?>